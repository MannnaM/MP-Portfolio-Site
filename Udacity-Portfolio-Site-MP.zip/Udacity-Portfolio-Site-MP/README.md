# Udacity Front-End Nanodegree - Portfolio Project 
## Udacity Portfolio Site

Final project of the first section in the Udacity Front-End Nanodegree Program. It is a simple one page portfolio featuring responsive design using the bootstrap framework. 


To view the site on github pages go to https://github.com/MannnaM/MP-Portfolio-Site